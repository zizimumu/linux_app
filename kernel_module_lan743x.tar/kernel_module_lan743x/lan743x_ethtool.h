/* SPDX-License-Identifier: GPL-2.0+ */
/* Copyright (C) 2018 Microchip Technology Inc. */

#ifndef _LAN743X_ETHTOOL_H
#define _LAN743X_ETHTOOL_H

#include "linux/ethtool.h"

extern const struct ethtool_ops lan743x_ethtool_ops;

#endif /* _LAN743X_ETHTOOL_H */
